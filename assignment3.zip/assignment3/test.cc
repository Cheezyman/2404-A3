#include "TestControl.h"

int main(){
    TestControl control;
    control.launch();
    return 0;
}